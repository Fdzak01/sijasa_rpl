<footer id="footer" class="footer fixed-bottom bg-white">
    <div class="copyright">
        &copy; Copyright <strong><span>SIJASA</span></strong>. All Rights Reserved
    </div>
</footer>
<?php /**PATH C:\Users\ghirama\Desktop\sijasa\resources\views/admin/layouts/components/footer.blade.php ENDPATH**/ ?>