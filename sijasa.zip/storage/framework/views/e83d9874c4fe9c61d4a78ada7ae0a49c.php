<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('dashboard')); ?>">
                <span>Dashboard</span>
            </a>
        </li>

        <?php if(Auth::user()->role == 'admin'): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('pengguna')); ?>">
                    <span>Pengguna</span>
                </a>
            </li>
        <?php endif; ?>

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('category-service')); ?>">
                <span>Kategori Pelayanan</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('service')); ?>">
                <span>Pelayanan</span>
            </a>
        </li>

    </ul>

</aside>
<?php /**PATH C:\Users\ghirama\Desktop\sijasa\resources\views/admin/layouts/components/sidebar.blade.php ENDPATH**/ ?>