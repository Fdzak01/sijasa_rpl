

<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Pelayanan</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Pelayanan</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <a href="<?php echo e(route('service.create')); ?>" class="btn btn-primary btn-sm mb-3">Tambah Data</a>
                    <div class="card">
                        <div class="card-body">

                            <h5 class="card-title">Data Layanan</h5>

                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Layanan</th>
                                        <th>Thumbnail</th>
                                        <th>Description</th>
                                        <th>Price</th>
                                        <th>Estimasi</th>
                                        <th>Kategori</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->service); ?></td>
                                            <td><img src="<?php echo e(asset('storage/' . $item->thumbnail)); ?>"
                                                    alt="<?php echo e($item->service); ?>" width="50"></td>
                                            <td><?php echo e(Str::limit($item->description, 50, '...')); ?></td>
                                            <td><?php echo e($item->price); ?></td>
                                            <td><?php echo e($item->estimate); ?></td>
                                            <td><?php echo e($item->kategori_layanans->kategori); ?></td>
                                            <td class="d-flex gap-2">
                                                <a href="<?php echo e(route('service.edit', $item->id)); ?>"
                                                    class="btn btn-warning btn-sm">Edit</a>
                                                <form action="<?php echo e(route('service.destroy', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghirama\Desktop\sijasa\resources\views/admin/pelayanan/index.blade.php ENDPATH**/ ?>